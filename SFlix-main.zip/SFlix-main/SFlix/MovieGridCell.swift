//
//  MovieGridCell.swift
//  SFlix
//
//  Created by Guest User on 2/11/22.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    @IBOutlet weak var posterView: UIImageView!
    
}
